"""
AI生成建表语句工作线程
"""
from PyQt6.QtCore import QThread, pyqtSignal
import logging
from typing import List, Dict

logger = logging.getLogger(__name__)


class CreateTableAIWorker(QThread):
    """AI生成建表语句工作线程"""
    
    sql_generated = pyqtSignal(str)  # SQL生成完成信号
    error_occurred = pyqtSignal(str)  # 错误信号
    
    def __init__(self, ai_client, conversation_history: List[Dict], database: str = None, reference_schema: str = "", current_sql: str = "", db_type: str = None):
        super().__init__()
        self.ai_client = ai_client
        self.conversation_history = conversation_history
        self.database = database
        self.reference_schema = reference_schema  # 参考表结构
        self.current_sql = current_sql  # 当前的建表语句
        self.db_type = db_type  # 数据库类型
        self._should_stop = False
    
    def stop(self):
        """安全停止线程"""
        self._should_stop = True
        self.requestInterruption()
    
    def run(self):
        """执行AI生成建表语句（在工作线程中运行）"""
        try:
            if self.isInterruptionRequested() or self._should_stop:
                return
            
            # 此 Worker 已被 CreateTableLangGraphWorker 替代，提示词使用内置常量
            from src.core.prompts import CREATE_TABLE_GENERATE_SQL_SYSTEM_PROMPT
            system_prompt = CREATE_TABLE_GENERATE_SQL_SYSTEM_PROMPT
            
            # 添加数据库类型信息到系统提示词
            if self.db_type:
                db_type_name_map = {
                    "mysql": "MySQL",
                    "mariadb": "MariaDB",
                    "postgresql": "PostgreSQL",
                    "oracle": "Oracle",
                    "sqlserver": "SQL Server",
                    "sqlite": "SQLite",
                }
                db_type_name = db_type_name_map.get(self.db_type.lower(), self.db_type)
                system_prompt += f"\n\n【重要】当前数据库类型: {db_type_name}\n请根据 {db_type_name} 的SQL语法规范生成CREATE TABLE语句，注意不同数据库的语法差异（如字段类型、主键设置、自增语法、默认值语法等）。"
            
            # 构建用户提示词（包含对话历史）
            conversation_text = "\n".join([
                f"{'用户' if msg['role'] == 'user' else 'AI'}: {msg['content']}"
                for msg in self.conversation_history[-10:]  # 只使用最近10条消息
            ])
            
            # 构建用户提示词
            reference_section = ""
            if self.reference_schema and self.reference_schema.strip():
                reference_section = f"""
【参考表结构（请参考这些表的结构风格）】
{self.reference_schema}

请参考上述表结构的命名规范、字段类型、主键设置等风格来生成新的建表语句。"""
            
            current_sql_section = ""
            if self.current_sql and self.current_sql.strip():
                current_sql_section = f"""
【当前的建表语句】
{self.current_sql}

如果用户要求修改或补充，请基于上述当前的建表语句进行修改和完善。"""
            
            db_type_info = ""
            if self.db_type:
                db_type_name_map = {
                    "mysql": "MySQL",
                    "mariadb": "MariaDB",
                    "postgresql": "PostgreSQL",
                    "oracle": "Oracle",
                    "sqlserver": "SQL Server",
                    "sqlite": "SQLite",
                }
                db_type_name = db_type_name_map.get(self.db_type.lower(), self.db_type)
                db_type_info = f"\n数据库类型: {db_type_name}\n请使用 {db_type_name} 的SQL语法规范。"
            
            user_prompt = f"""【对话历史】
{conversation_text}

【当前数据库】
数据库名: {self.database if self.database else '未指定'}{db_type_info}{reference_section}{current_sql_section}

【你的任务】
根据上述对话历史，生成完整的CREATE TABLE语句。如果用户只是补充或修改，请基于之前的对话或当前的建表语句生成完整的表结构。
如果提供了参考表结构，请保持与参考表结构一致的风格（命名规范、字段类型、主键设置等）。
如果提供了当前的建表语句，请基于它进行修改和完善，而不是完全重新生成。"""
            
            if self.isInterruptionRequested() or self._should_stop:
                return
            
            response = self.ai_client.chat_complete(
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt},
                ],
                caller="create_table_ai",
            )
            
            if self.isInterruptionRequested() or self._should_stop:
                return
            
            sql = response.choices[0].message.content.strip()
            
            # 清理SQL（移除可能的markdown代码块标记）
            if sql.startswith("```sql"):
                sql = sql[6:]
            elif sql.startswith("```"):
                sql = sql[3:]
            if sql.endswith("```"):
                sql = sql[:-3]
            sql = sql.strip()
            
            # 发送结果
            self.sql_generated.emit(sql)
            
        except Exception as e:
            error_msg = str(e)
            logger.error(f"AI生成建表语句失败: {error_msg}")
            self.error_occurred.emit(error_msg)
        finally:
            # 注意：QThread 的 run() 方法返回时，线程会自动结束，finished 信号会自动触发

            # 不需要调用 quit()，因为 QThread.run() 默认没有事件循环

            pass

